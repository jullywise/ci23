<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pengajuan Surat</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?= base_url('css/bootstrap.min.css') ?>">
    <!-- Tema Bootstrap - Cosmo -->
    <link rel="stylesheet" href="https://bootswatch.com/5/cosmo/bootstrap.min.css">
</head>

<body>

    <?= $this->include('navbar_mahasiswa') ?>

    <header class="jumbotron">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h1 class="h1">Pengajuan Surat</h1>
                </div>
            </div>
        </div>
    </header>

    <div class="container">
        <div class="row">
            <div class="col-md-6">
            <form action="<?= site_url('page/createSurat'); ?>" class="form" method="post">
			<input type="hidden" name="nim" value="<?= $nim ?>">
			<div class="form-group">
                <label for="select">Pilih jenis surat yang Anda ajukan:</label>
				<select class="form-control" name="surat">
				  <option selected>Jenis Surat</option>
				  <option value="Aktif Kuliah">Keterangan Aktif Kuliah</option>
				  <option value="Izin Magang">Pengantar Magang</option>
				  <option value="Surat Tugas">Surat Tugas</option>
				</select>
			</div>
			
			<div class="form-group">
                <label for="keterangan">Keterangan:</label>
                <textarea class="form-control" name="keterangan" rows="3"></textarea>
            </div>
			
			<div class="form-group">
                <input type="submit" value="Submit" class="btn btn-info">
            </div>
            </form>

            </div>
        </div>
    </div>

    <?= $this->include('footer') ?>

    	<!-- Jquery dan Bootsrap JS -->
	<script src="<?= base_url('js/jquery.min.js') ?>"></script>
	<script src="<?= base_url('js/bootstrap.min.js') ?>"></script>

</body>

</html>