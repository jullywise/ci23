<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Pengajuan Surat</title>

    <!-- Bootstrap CSS -->
	  <link rel="stylesheet" href="<?= base_url('css/bootstrap.min.css') ?>">
    <!-- Tema Bootstrap - Cosmo -->
    <link rel="stylesheet" href="https://bootswatch.com/5/cosmo/bootstrap.min.css">
</head>

<body>

    <?php
		if($isAdmin){
			include('navbar_admin.php');
		}else{
			include('navbar_mahasiswa.php');
		}
	?>

    <header class="jumbotron">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h1 class="h1">Daftar Pengajuan Surat</h1>
                </div>
            </div>
        </div>
    </header>

    <div class="container">
        <div class="row">
            <div class="col-md-12">
				<?php if (!empty(session()->getFlashdata('msg'))) : ?>
					<div class="alert alert-success alert-dismissible fade show" role="alert">
					<?php echo session()->getFlashdata('msg'); ?>
					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
					</div>
                <?php endif; ?>
				<table class="table table-hover table-striped">
				  <thead>
					<tr class="table-primary">
					  <th scope="col">#</th>
					  <th scope="col">Kode Surat</th>
					  <th scope="col">Jenis Surat</th>
					  <th scope="col">Tgl. Diajukan</th>
					  <th scope="col">Tgl. Disetujui</th>
					  <th scope="col">Keterangan</th>
					  <th scope="col">Status</th>
					  <th scope="col">Action</th>
					</tr>
				  </thead>
				  <tbody>
					<?php if( !empty($surat) ) {
						$n=1;
						foreach($surat as $row){ ?>
						<tr>
							<th><?php echo $n++; ?></th>
							<td><?= $row['kode_surat'];?></td>
							<td><?= $row['jenis_surat'];?></td>
							<td><?= $row['tgl_diajukan'];?></td>
							<td><?= $row['tgl_pengesahan'];?></td>
							<td><?= $row['keterangan'];?></td>
							<td><?= $row['status'];?></td>
							<td><?php
								if($isAdmin){
									echo "<a href='".site_url('surat/detail/'.$row['id'])."'>Lihat</a> | <a href='".site_url('surat/edit/'.$row['id'])."'>Ubah</a>";
								}else{
									if($row['gambar'] != ""){
										?>
										<a href='<?= base_url() ?>/uploads/<?= $row['gambar'];?>'>Download</a>
										<?php
									}
								}
							?></td>
						</tr>
					<?php }
					}else{
						?>
						<tr>
						  <td colspan="8">Data Tidak Ditemukan</td>
						</tr>
						<?php
					} ?>
				  </tbody>
				</table>

            </div>
        </div>
    </div>

    <?= $this->include('footer') ?>

    	<!-- Jquery dan Bootsrap JS -->
	<script src="<?= base_url('js/jquery.min.js') ?>"></script>
	<script src="<?= base_url('js/bootstrap.min.js') ?>"></script>

</body>

</html>