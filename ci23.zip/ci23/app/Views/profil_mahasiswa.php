<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil Mahasiswa</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?= base_url('css/bootstrap.min.css') ?>">
    <!-- Tema Bootstrap - Cosmo -->
    <link rel="stylesheet" href="https://bootswatch.com/5/cosmo/bootstrap.min.css">
</head>

<body>

    <?= $this->include('navbar_mahasiswa') ?>
    <?= view('header', ['judul' => 'Profil Mahasiswa ' . $nama]) ?>

    <?php
    $msg = session()->getFlashdata('msg');
    ?>
    <?php if ($msg != null) : ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?= $msg ?>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <form action="#" class="form" method="post">
                    <div class="row mb-3">
                        <label for="nim" class="col-sm-3 col-form-label">NIM:</label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" id="nim" name="nim" value="<?= $nim ?>" readonly>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <label for="jenisKelamin" class="col-sm-3 col-form-label">Jenis Kelamin:</label>
                        <div class="col-sm-9">
                            <select class="form-control" id="jenisKelamin" name="jenisKelamin" disabled>
                                <option value="Pria" <?php if ($kelamin == 'Laki-laki') echo 'selected' ?>>Pria</option>
                                <option value="Wanita" <?php if ($kelamin == 'Perempuan') echo 'selected' ?>>Wanita</option>
                            </select>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <label for="alamat" class="col-sm-3 col-form-label">Alamat:</label>
                        <div class="col-sm-9">
                            <textarea class="form-control" id="alamat" name="alamat" rows="3" readonly><?= $alamat ?></textarea>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <label for="email" class="col-sm-3 col-form-label">Email:</label>
                        <div class="col-sm-9">
                            <input type="email" class="form-control" id="email" name="email" value="<?= $email ?>" readonly>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <label for="noHp" class="col-sm-3 col-form-label">No. HP:</label>
                        <div class="col-sm-9">
                            <input type="tel" class="form-control" id="noHp" name="noHp" value="<?= $no_hp ?>" readonly>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <label for="jurusan" class="col-sm-3 col-form-label">Jurusan:</label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" id="jurusan" name="jurusan" value="<?= $jurusan ?>" readonly>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <label for="fakultas" class="col-sm-3 col-form-label">Fakultas:</label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" id="fakultas" name="fakultas" value="<?= $fakultas ?>" readonly>
                        </div>
                    </div>

                    <div class="form-group text-center">
                        <a href="<?= base_url('ubah-password') ?>" class="btn btn-info">Ubah kata sandi</a>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <?= $this->include('footer') ?>

    <!-- Jquery dan Bootstrap JS -->
    <script src="<?= base_url('js/jquery.min.js') ?>"></script>
    <script src="<?= base_url('js/bootstrap.min.js') ?>"></script>

</body>

</html>
