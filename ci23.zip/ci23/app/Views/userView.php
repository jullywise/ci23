<!DOCTYPE html>
<html lang="en">
<head>
        <title>User List</title>
</head> 
<body>
    <table border="1"> 
        <tr>
            <th>Email</th>
            <th>Password</th>
        </tr>
        <?php if( !empty($users) ) {
            foreach ($users as $row) { ?> 
            <tr>
                <td><?= $row['email']; ?></td>
                <td><?= $row['password']; ?></td>
            </tr>
        <?php   }
        } ?> 
        </table>
    </body>
    </html>
