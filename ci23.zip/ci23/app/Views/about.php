<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tentang Kami</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?= base_url('css/bootstrap.min.css') ?>" />
    <!-- Tema Bootstrap - Cosmo -->
    <link rel="stylesheet" href="https://bootswatch.com/5/cosmo/bootstrap.min.css">
    <style>
        .clickable {
            cursor: pointer;
        }

        .clickable:hover {
            text-decoration: underline;
        }
    </style>
</head>

<body>

    <nav class="navbar navbar-expand-lg navbar-dark bg-info text-white">
        <div class="container">
            <a class="navbar-brand" href="<?= base_url() ?>">Home</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="<?= base_url('about') ?>">About</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?= base_url('contact') ?>">Contact</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?= base_url('faqs') ?>">Faqs</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?= base_url('welcome_message') ?>">news</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <header class="jumbotron">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h1 class="h1">Tentang Kami</h1>
                </div>
            </div>
        </div>
    </header>

    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1 class="h2"><i>Visi</i></h2>
                <p>Menjadi lembaga pelayanan dokumen yang terbaik dan melayani dengan sepenuh hati</p>
            
                <br>

                <h1 class="h2"><i>Misi</i></h2>
                <ul>
                    <li class="clickable">Memenuhi setiap kebutuhan anda dengan sigap, tepat, dan cepat</li>
                    <li class="clickable">Memberikan pelayanan terbaik demi kepuasan anda</li>
                    <li class="clickable">Memberikan solusi terbaik dalam permasalahan yang dihadapi</li>
                </ul>

                <br>

                <h1 class="h2"><i>Jam Kerja dan Pelayanan</i></h2>
                <p>Jam Kerja: Senin - Jumat, Pukul 08.00 - 17.00</p>
                <p>Pelayanan:</p>
                <ul>
                    <li class="clickable">Pendaftaran Dokumen</li>
                    <li class="clickable">Permintaan Informasi</li>
                    <li class="clickable">Konsultasi Dokumen</li>
                    <li class="clickable">Pengiriman Dokumen</li>
                </ul>
            </div>
        </div>
    </div>

    <?= $this->include('footer') ?>

    <!-- Jquery dan Bootsrap JS -->
    <script src="<?= base_url('js/jquery.min.js') ?>"></script>
    <script src="<?= base_url('js/bootstrap.min.js') ?>"></script>
    <script>
        // Fungsi untuk menangani klik pada elemen
        document.addEventListener('DOMContentLoaded', function() {
            var clickableItems = document.getElementsByClassName('clickable');
            for (var i = 0; i < clickableItems.length; i++) {
                clickableItems[i].addEventListener('click', function() {
                    // Tindakan yang ingin diambil saat elemen diklik
                });
            }
        });
    </script>
</body>

</html>
