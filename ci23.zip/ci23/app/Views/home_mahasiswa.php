<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home - Mahasiswa</title>

      <!-- Bootstrap CSS -->
      <link rel="stylesheet" href="<?= base_url('css/bootstrap.min.css') ?>">
    <!-- Tema Bootstrap - Cosmo -->
    <link rel="stylesheet" href="https://bootswatch.com/5/cosmo/bootstrap.min.css">
</head>

<body>

    <?= $this->include('navbar_mahasiswa') ?>

    <header class="jumbotron">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h1 class="h1">Selamat Datang Mahasiswa</h1>
                </div>
            </div>
        </div>
    </header>

    <div class="container">
        <div class="row">
            <div class="col-md-6">
            
            <h3 class="h3">Welcome back <?= $nama ?>!</h3>
			Email: <?= $email ?>
            </div>
        </div>
    </div>

    <?= $this->include('footer') ?>

    	<!-- Jquery dan Bootsrap JS -->
	<script src="<?= base_url('js/jquery.min.js') ?>"></script>
	<script src="<?= base_url('js/bootstrap.min.js') ?>"></script>

</body>

</html>