<header class="jumbotron">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1 class="h1" style="color: black; font-family: 'Calibri', sans-serif; font-weight: 500; font-size: 60px;" 
                ><?= esc($judul) ?></h1>
            </div>
        </div>
    </div>
</header>