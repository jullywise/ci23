<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ubah Password</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?= base_url('css/bootstrap.min.css') ?>">
    <!-- Tema Bootstrap - Cosmo -->
    <link rel="stylesheet" href="https://bootswatch.com/5/cosmo/bootstrap.min.css">
</head>

<body>

    <?= $this->include('navbar_mahasiswa') ?>

    <?= view('header', ['judul' => 'Ubah Kata Sandi']) ?>

    <?php
    $msg = session()->getFlashdata('msg');
    ?>
    <?php if ($msg != null) : ?>
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-6">
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?= $msg ?>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <form action="<?= base_url('ubah-password') ?>" class="form" method="post">
                    <div class="form-group">
                        <label for="nim">Kata sandi baru:</label>
                        <input type="text" class="form-control" id="password" name="password" placeholder="kata sandi baru">
                    </div>
                    <div class="form-group">
                        <label for="nim">Ulangi kata sandi baru:</label>
                        <input type="text" class="form-control" id="password-ulangi" name="password-ulangi" placeholder="Ulangi">
                    </div>

                    <div class="form-group text-center">
                        <input type="submit" class="btn btn-info" value="Selesai">
                    </div>
                </form>
            </div>
        </div>
    </div>

    <?= $this->include('footer') ?>

    <!-- Jquery dan Bootsrap JS -->
    <script src="<?= base_url('js/jquery.min.js') ?>"></script>
    <script src="<?= base_url('js/bootstrap.min.js') ?>"></script>

</body>

</html>
