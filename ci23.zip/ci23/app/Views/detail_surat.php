<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Surat</title>

    <!-- Bootstrap CSS -->
	<link rel="stylesheet" href="<?= base_url('css/bootstrap.min.css') ?>">
    <!-- Tema Bootstrap - Cosmo -->
    <link rel="stylesheet" href="https://bootswatch.com/5/cosmo/bootstrap.min.css">
</head>

<body>

    <?= $this->include('navbar_admin') ?>

    <header class="jumbotron">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h1 class="h1">Detail Surat</h1>
                </div>
            </div>
        </div>
    </header>

    <div class="container">
        <div class="row">
            <div class="col-md-12">
				<a class="btn btn-primary" href="<?= site_url('surat-admin') ?>">Back</a>
				<table class="table table-hover table-striped">
				  <tbody>
					<tr>
					  <td class="col-md-3">ID</td>
					  <td>: <?= $surat['id'];?></td>
					</tr>
					<tr>
					  <td class="col-md-3">Kode Surat</td>
					  <td>: <?= $surat['kode_surat'];?></td>
					</tr>
					<tr>
					  <td class="col-md-3">Jenis Surat</td>
					  <td>: <?= $surat['jenis_surat'];?></td>
					</tr>
					<tr>
					  <td class="col-md-3">Yang Mengajukan (NIM)</td>
					  <td>: <?= $surat['nim'];?></td>
					</tr>
					<tr>
					  <td class="col-md-3">Tgl. Diajukan</td>
					  <td>: <?= $surat['tgl_diajukan'];?></td>
					</tr>
					<tr>
					  <td class="col-md-3">Tgl. Disetujui</td>
					  <td>: <?= $surat['tgl_pengesahan'];?></td>
					</tr>
					<tr>
					  <td class="col-md-3">Status</td>
					  <td>: <?= $surat['status'];?></td>
					</tr>
					<tr>
					  <td class="col-md-3">Gambar</td>
					  <td>: <a href='<?= base_url() ?>/uploads/<?= $surat['gambar'];?>'><?= $surat['gambar'];?></a></td>
					</tr>
					<tr>
					  <td class="col-md-3">	Keterangan</td>
					  <td>: <?= $surat['keterangan'];?></td>
					</tr>
				  </tbody>
				</table>
			</div>
        </div>
    </div>

    <?= $this->include('footer') ?>

    	<!-- Jquery dan Bootsrap JS -->
	<script src="<?= base_url('js/jquery.min.js') ?>"></script>
	<script src="<?= base_url('js/bootstrap.min.js') ?>"></script>

</body>

</html>