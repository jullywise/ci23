<nav class="navbar navbar-expand-lg navbar-dark bg-info text-white">
	<div class="container">
		<a class="navbar-brand" href="<?= site_url('admin') ?>">Home</a>
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>
		<div class="collapse navbar-collapse" id="navbarNav">
			<ul class="navbar-nav ml-auto">

				<li class="nav-item">
					<a class="nav-link" href="<?= site_url('profil_mahasiswa') ?>">Profil</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="<?= site_url('daftar-pengajuan') ?>">Daftar Pengajuan</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="<?= site_url('surat') ?>">Pengajuan Surat</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="<?= site_url('logout') ?>">Logout</a>
				</li>
				
			</ul>
		</div>
	</div>
</nav>