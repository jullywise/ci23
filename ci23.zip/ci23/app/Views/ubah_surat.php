<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Surat</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?= base_url('css/bootstrap.min.css') ?>" />
</head>

<body>

    <?= $this->include('navbar_admin') ?>

    <header class="jumbotron">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h1 class="h1">Detail Surat</h1>
                </div>
            </div>
        </div>
    </header>

    <div class="container">
        <div class="row">
            <div class="col-md-12">
				<form action="<?= site_url('page/editSurat'); ?>" class="form" method="post" enctype="multipart/form-data">
				<input type="hidden" name="id" value="<?= $surat['id'] ?>">
				<table class="table table-hover table-striped">
				  <tbody>
					<tr>
					  <td class="col-md-3">ID</td>
					  <td>: <?= $surat['id'];?></td>
					</tr>
					<tr>
					  <td class="col-md-3">Kode Surat</td>
					  <td>: <input type="text" name="kode_surat" value="<?= $surat['kode_surat'];?>"></td>
					</tr>
					<tr>
					  <td class="col-md-3">Jenis Surat</td>
					  <td>: <?= $surat['jenis_surat'];?></td>
					</tr>
					<tr>
					  <td class="col-md-3">Yang Mengajukan (NIM)</td>
					  <td>: <?= $surat['nim'];?></td>
					</tr>
					<tr>
					  <td class="col-md-3">Tgl. Diajukan</td>
					  <td>: <?= $surat['tgl_diajukan'];?></td>
					</tr>
					<tr>
					  <td class="col-md-3">Tgl. Disetujui</td>
					  <td>: <?= $surat['tgl_pengesahan'];?></td>
					</tr>
					<tr>
					  <td class="col-md-3">Status</td>
					  <td>: <?= $surat['status'];?>
						<select class="form-control" name="status" required>
						  <option value="">Pilih Status</option>
						  <option value="Pengecekan">Pengecekan</option>
						  <option value="Pemrosesan">Pemrosesan</option>
						  <option value="Kadep">Kadep</option>
						  <option value="Dekanat">Dekanat</option>
						  <option value="Ditolak">Ditolak</option>
						  <option value="Selesai">Selesai</option>
						</select>
					  </td>
					</tr>
					<tr>
					  <td class="col-md-3">Gambar</td>
					  <td>: 
					  	<a href='<?= base_url() ?>/uploads/<?= $surat['gambar'];?>'><?= $surat['gambar'];?></a>

					  <input type="file" class="form-control" name="gambar"></td>
					</tr>
					<tr>
					  <td class="col-md-3">	Keterangan</td>
					  <td>: <?= $surat['keterangan'];?></td>
					</tr>
					<tr align="right">
					  <td colspan="2">
					  <a class="btn btn-dark" href="<?= site_url('surat-admin') ?>">Cancel</a>
					  <input type="submit" class="btn btn-info" value="Save" />
					  </td>
					</tr>
				  </tbody>
				</table>
				</form>
			</div>
        </div>
    </div>

    <?= $this->include('footer') ?>

    	<!-- Jquery dan Bootsrap JS -->
	<script src="<?= base_url('js/jquery.min.js') ?>"></script>
	<script src="<?= base_url('js/bootstrap.min.js') ?>"></script>

</body>

</html>