<?php
 
namespace App\Models;
 
use CodeIgniter\Model;
 
class SuratModel extends Model
{
    protected $table      = 'surat';
    protected $primaryKey = 'id';

	protected $allowedFields = ['nim', 'jenis_surat','keterangan', 'status','kode_surat','tgl_pengesahan','gambar'];

}
