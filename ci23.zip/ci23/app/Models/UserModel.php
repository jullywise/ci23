<?php
 
namespace App\Models;
 
use CodeIgniter\Model;
 
class UserModel extends Model
{
    protected $table      = 'user';
    protected $primaryKey = 'nip_nim';

    // Fillable
    protected $allowedFields = ['nip_nim', 'password'];

 
    public function getData()
    {
        $users = new UserModel();
        return $users->findAll();
    }
}