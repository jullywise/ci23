<?php 
namespace App\Controllers;
use App\Models\UserModel;
use App\Models\AdminModel;
use App\Models\MahasiswaModel;
use App\Models\SuratModel;

class Page extends BaseController
{
	
	public function about()
	{
		echo view("about");
	}
    
    public function contact()
	{
		echo view("contact");
	}

	public function login()
	{
		echo view("login");
	}
	
	public function faqs()
	{
		echo view("faqs");
	}

	public function news()
	{
		echo view("welcome_message");
	}
	
	public function surat()
	{
		$session = session();
		if($session->get('nim') == null){
			$data['msg'] = "Maaf, Anda harus Login!";
			echo view("login", $data);
		}else{
			$data['nim'] = $session->get('nim');
			echo view("pengajuan_surat", $data);
		}
	}
	
	public function logout()
	{
		$session = session();
		$session->remove('nip');
		$session->remove('nim');
		$session->destroy();
		return redirect()->to(site_url("home"));
	}
	
	public function admin()
	{
		$session = session();
		if($session->get('nip') == null){
			$data['msg'] = "Maaf, Anda harus Login!";
			echo view("login", $data);
		}else{
			$nip = $session->get('nip');
			$admin = new AdminModel();
			$data = $admin->where('nip',''.$nip)->first();
			$data['nama'] = $data['nama'];
			$data['email'] = $data['email'];
			echo view("home_admin", $data);
		}
		//echo view("home_admin");
	}
	
	public function mahasiswa()
	{
		$session = session();
		if($session->get('nim') == null){
			$data['msg'] = "Maaf, Anda harus Login!";
			echo view("login", $data);
		}else{
			$nim = $session->get('nim');
			$mahasiswa = new MahasiswaModel();
			$data = $mahasiswa->where('nim',''.$nim)->first();
			$data['nama'] = $data['nama'];
			$data['email'] = $data['email'];
			echo view("home_mahasiswa", $data);
		}
		//echo view("home_mahasiswa");
	}
	
	public function saveContact()
    {
		echo "<pre>";
		$data = $this->request->getVar();
        var_dump($data);
        echo "</pre>";
		
		echo $data["email"];
		echo $data["message"];
    }

    public function checkLogin()
    {
		$session = session();
		$data1 = $this->request->getVar();
		$nip_nim = $data1["nip_nim"];
		$password= SHA1($data1["password"]);

		$users = new UserModel();
        $data = $users->where('nip_nim',''.$nip_nim)->first();
        if( !empty($data) ) {
        	if($data['password'] == $password){
				if($data['tingkat'] == "admin"){
					/* $admin = new AdminModel();
					$data2 = $admin->where('nip',''.$nip_nim)->findAll();
					$data['nama'] = $data2[0]['nama'];
					$data['email'] = $data2[0]['email'];
					echo view("home_admin", $data); */
					$session->set('nip',$nip_nim);
					return redirect()->to(site_url("admin"));
				}else{
					/* $mahasiswa = new MahasiswaModel();
					$data2 = $mahasiswa->where('nim',''.$nip_nim)->first();
					$data['nama'] = $data2['nama'];
					$data['email'] = $data2['email'];
					echo view("home_mahasiswa", $data); */
					$session->set('nim',$nip_nim);
					return redirect()->to(site_url("mahasiswa"));
				}
				
        	}else{
        		$data['msg'] = "password salah";
				echo view("message", $data);
        	}
        	
        }else{
    		$data['msg'] = "Invalid Login!";
			echo view("message", $data);
        }
    }

	public function users()
	{
		$users = new UserModel();
        $data['users'] = $users->getData();
        echo view('userView', $data);
	}
	
	public function createSurat()
	{
		$model = new SuratModel();
        $data = [
            'nim' => $this->request->getVar('nim'),
            'jenis_surat'  => $this->request->getVar('surat'),
			'keterangan'  => $this->request->getVar('keterangan'),
			'status'  => "Pengecekan"
        ];
        $insert = $model->insert($data);
        if($insert){
			return redirect()->to(site_url("daftar-pengajuan"));
		}else{
			echo "<pre>";
            echo print_r($model->errors());
            echo "</pre>";
		}
	}
	
	public function daftarPengajuan()
	{
		$surat = new SuratModel();
		$data['isAdmin'] = false;
        $data['surat'] = $surat->orderBy('tgl_diajukan', 'DESC')->findAll();
        echo view('daftar_pengajuan', $data);
	}
	
	public function daftarSurat()
	{
		$surat = new SuratModel();
		$data['isAdmin'] = true;
        $data['surat'] = $surat->orderBy('tgl_diajukan', 'DESC')->findAll();
        echo view('daftar_pengajuan', $data);
	}
	
	public function detailSurat($id)
	{
		$surat = new SuratModel();
		$data['isAdmin'] = true;
        $data['surat'] = $surat->where('id',$id)->first();
        echo view('detail_surat', $data);
	}
	
	public function updateSurat($id)
	{
		$surat = new SuratModel();
		$data['isAdmin'] = true;
        $data['surat'] = $surat->where('id',$id)->first();
        echo view('ubah_surat', $data);
	}
	
	public function editSurat()
	{
		$model = new SuratModel();
		$id=$this->request->getVar('id');
		$dataBerkas = $this->request->getFile('gambar');
		if($dataBerkas != ""){
			$fileName = $dataBerkas->getRandomName();
			$data = [
				'id' => $id,
				'kode_surat'  => $this->request->getVar('kode_surat'),
				'gambar' => $fileName,
				'status'  => $this->request->getVar('status')
			];

			if($this->request->getVar('status') == "Selesai"){
				$data['tgl_pengesahan'] = date("Y-m-d");
			}

			$dataBerkas->move('uploads/', $fileName);
			$insert = $model->update($id, $data);
		}else{
			$data = [
				'id' => $id,
				'kode_surat'  => $this->request->getVar('kode_surat'),
				'status'  => $this->request->getVar('status')
			];

			if($this->request->getVar('status') == "Selesai"){
				$data['tgl_pengesahan'] = date("Y-m-d");
			}

			$insert = $model->update($id, $data);
		}

		session()->setFlashdata('msg', 'Data Berhasil Diubah');
        if($insert){
			return redirect()->to(site_url("surat-admin"));
		}else{
			echo "<pre>";
            echo print_r($model->errors());
            echo "</pre>";
		}
	}

	public function profilMahasiswa()
	{
		$session = session();
		if($session->get('nim') == null){
			$data['msg'] = "Maaf, Anda harus Login!";
			echo view("login", $data);
		}else{
			$nim = $session->get('nim');
			$mahasiswa = new MahasiswaModel();
			$data = $mahasiswa->where('nim',''.$nim)->first();
			echo view("profil_mahasiswa", $data);
		}
	}

	public function ubahPassword()
{
    $session = session();
    if ($session->get('nim') == null) {
        $data['msg'] = "Maaf, Anda harus Login!";
        echo view("login", $data);
    } else {
        $nim = $session->get('nim');
        $mahasiswa = new MahasiswaModel();
        $data = $mahasiswa->where('nim', '' . $nim)->first();
        $data['msg'] = session()->getFlashdata('msg'); // notifikasi untuk pnambahan data
        echo view("ubah_password", $data);
    }
}

public function updatePassword()
{
    $model = new UserModel();
    $session = session();
    $nim = $session->get('nim');

    if ($this->request->getVar('password') != $this->request->getVar('password-ulangi')) {
        session()->setFlashdata('msg', 'Password harus sama!'); //flash data untuk muncul tulisan psan
        return redirect()->to(site_url("ubah-password"));
    }

    $data = [
        'nip_nim' => $nim,
        'password'  => SHA1($this->request->getVar('password')) //sha1 mngubah nilai password
    ];

    $insert = $model->update($nim, $data);
    if ($insert) {
        session()->setFlashdata('msg', 'Kata sandi Berhasil Diubah'); //bnar
        return redirect()->to(site_url("profil_mahasiswa"));
    } else {
        session()->setFlashdata('msg', 'Gagal mengubah kata sandi'); // salah
        echo "<pre>";
        echo print_r($model->errors());
        echo "</pre>";
    }
}

}
?>

	